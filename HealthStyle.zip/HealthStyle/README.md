This is the Readme for our CS 4530 group. Details about our group (i.e. roles) and project design choices/running instructions should go here.
Ideally we'll only use this one repo for each project (makes for easier management). Projects will be organized in their own directories in the repo.
(e.g. `Project1/`, `Project2/`, and so on)

Project 1:

Team Lead: Joshua Cragun

UI Lead: Ryan Brooks

Testing Lead: Brendan Ngeh

General Support: Jingwen Zhang
