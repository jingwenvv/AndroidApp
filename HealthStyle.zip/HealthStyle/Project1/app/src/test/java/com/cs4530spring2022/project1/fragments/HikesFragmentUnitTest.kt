package com.cs4530spring2022.project1.fragments

import android.location.Location
import org.junit.runner.RunWith
import org.junit.runners.JUnit4

@RunWith(JUnit4::class)
class HikesFragmentUnitTest {

    private val loc: Location? = null
}