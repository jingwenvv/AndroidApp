package com.cs4530spring2022.project1.util

interface UpdateNavBar{
    fun showNavBar(show:Boolean)
    fun setNavBar(name:String)
}